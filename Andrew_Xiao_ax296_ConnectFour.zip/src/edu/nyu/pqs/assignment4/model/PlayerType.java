package edu.nyu.pqs.assignment4.model;
/**
 * This enum represents a PlayerType which comes in two flavors: human or computer
 * @author Andrew
 *
 */
public enum PlayerType {
	HUMAN,
	COMPUTER;
}
