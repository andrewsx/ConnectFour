# Welcome to Connect Four!


The rules are simple. There are two players who take turns (Player One is red, Player Two is yellow)
filling the board until one gets a win either horizontally, vertically, or diagonally. Please run the Application.java to start the game.
The GUI will pop up and allow the user to pick the game mode: either against the computer or with a friend. Afterwards, hit the start button and enjoy!



